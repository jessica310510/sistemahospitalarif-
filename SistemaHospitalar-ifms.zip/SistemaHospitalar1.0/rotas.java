
public class rotas {
	
	public static String MEDICO="/view/medicos.fxml";

}
